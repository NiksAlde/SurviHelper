package com.example.survivalhelper;

import net.fabricmc.api.ModInitializer;

public class SurvivalHelper implements ModInitializer {
    @Override
    public void onInitialize() {
        System.out.println("Survival Helper Loaded!");
    }
}
