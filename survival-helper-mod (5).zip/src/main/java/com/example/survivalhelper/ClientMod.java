package com.example.survivalhelper;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;

public class ClientMod implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        HudRenderCallback.EVENT.register(this::renderHud);
    }

    private void renderHud(MatrixStack matrices, float tickDelta) {
        MinecraftClient client = MinecraftClient.getInstance();

        if (client.player == null || client.world == null) return;

        int health = (int) client.player.getHealth();
        int hunger = client.player.getHungerManager().getFoodLevel();

        int x = 10;
        int y = 10;

        if (health <= 6) {
            client.textRenderer.drawWithShadow(matrices, "LOW HEALTH!", x, y, 0xFF0000);
            y += 10;
        }

        if (hunger <= 6) {
            client.textRenderer.drawWithShadow(matrices, "EAT FOOD!", x, y, 0xFFFF00);
            y += 10;
        }

        String coords = "XYZ: " + (int)client.player.getX() + " " +
                        (int)client.player.getY() + " " +
                        (int)client.player.getZ();

        client.textRenderer.drawWithShadow(matrices, coords, x, y, 0xFFFFFF);
    }
}
